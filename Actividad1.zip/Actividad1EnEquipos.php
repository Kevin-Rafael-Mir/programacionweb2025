<?php
$tripulacion =['Alex Rider','Mia Kovalik','Raj Patel','Elena Vega','Jules Bergman']; // Crear el Array

echo $tripulacion[2]; //Mostrar el tercer tripulante (índice 2)

$tripulacion[1]="Nadia Petrov"; //Reemplazar a Mia Kovalik por Nadia Petrov.

var_dump($tripulacion); //Comprobación.

$tripulacion[]='Sam Carter'; //Añadir a Sam Carter como un nuevo tripulante

$tripulacion[]='Leo Wu';//Añadir a Leo Wucomo un nuevo tripulante

$tripulacion[]='Zara Khan';//Añadir a Zara Khan como un nuevo tripulante

var_dump($tripulacion);//Comprobación.
//Hecho por Kevin Mir, Benjamín Gigena y Bruno Hernández.
?>